
import Skardu from "../assets/Skardu.jpeg";
import Summer from "../assets/Summer.jpg";
import Gilgit2 from "../assets/gilgit.jpg";



export const DestList = [
  {
    id: 1,
    name: "swat",
    image: Summer,
  
   

  },
  {
    id: 2,
    name: "skardu",
    image: Skardu,
  

  },
  {
    id: 3,
    name: "hunza",
    image: Gilgit2,


  }
];
