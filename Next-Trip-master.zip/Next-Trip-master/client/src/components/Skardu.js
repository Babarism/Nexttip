import React from 'react';
import SkarduHelper from '../helpers/SkarduHelper';


const Skardu = () => {

  return (
    <div>
      <SkarduHelper />
    </div>
  );
};

export default Skardu;
