import React from 'react';
import SwatHelper from '../helpers/SwatHelper';


const Swat = () => {

  return (
    <div>
      <SwatHelper />
    </div>
  );
};

export default Swat;
