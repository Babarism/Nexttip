import React from 'react';
import HunzaHelper from '../helpers/HunzaHelper';

const Gilgit = () => {
  return (
    <div>
      <HunzaHelper />
    </div>
  );
};

export default Gilgit;
